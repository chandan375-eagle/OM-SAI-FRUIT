import { useState, useEffect } from 'react';

// Product Types
interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  emoji: string;
  category: string;
  priceRange?: string;
  seasonal?: boolean;
  premium?: boolean;
  outOfStock?: boolean;
}

// Product Data
const fruits: Product[] = [
  { id: 'f1', name: 'Apple', price: 250, unit: 'Kg', emoji: '🍎', category: 'fruits' },
  { id: 'f2', name: 'Pear', price: 250, unit: 'Kg', emoji: '🍐', category: 'fruits' },
  { id: 'f3', name: 'Pomegranate', price: 250, unit: 'Kg', emoji: '🫐', category: 'fruits' },
  { id: 'f4', name: 'Small WaterMelon', price: 70, unit: 'Piece', emoji: '🍉', category: 'fruits', priceRange: '60-80' },
  { id: 'f5', name: 'Medium WaterMelon', price: 95, unit: 'Piece', emoji: '🍉', category: 'fruits', priceRange: '80-110' },
  { id: 'f6', name: 'Big WaterMelon', price: 135, unit: 'Piece', emoji: '🍉', category: 'fruits', priceRange: '110-160' },
  { id: 'f7', name: 'Orange', price: 100, unit: 'Kg', emoji: '🍊', category: 'fruits' },
  { id: 'f8', name: 'Chikoo', price: 100, unit: 'Kg', emoji: '🥝', category: 'fruits' },
  { id: 'f9', name: 'Green Grapes', price: 160, unit: 'Kg', emoji: '🍇', category: 'fruits' },
  { id: 'f10', name: 'Black Grapes', price: 200, unit: 'Kg', emoji: '🍇', category: 'fruits' },
  { id: 'f11', name: 'Red Grapes', price: 200, unit: 'Kg', emoji: '🍇', category: 'fruits' },
  { id: 'f12', name: 'Line Muskmelon', price: 60, unit: 'Kg', emoji: '🍈', category: 'fruits' },
  { id: 'f13', name: 'White Muskmelon', price: 60, unit: 'Kg', emoji: '🍈', category: 'fruits' },
  { id: 'f14', name: 'Orange Muskmelon', price: 60, unit: 'Kg', emoji: '🍈', category: 'fruits' },
  { id: 'f15', name: 'Import Orange', price: 200, unit: 'Kg', emoji: '🍊', category: 'fruits' },
  { id: 'f16', name: 'Kiwi', price: 120, unit: 'Box', emoji: '🥝', category: 'fruits' },
  { id: 'f17', name: 'Dragon Fruit', price: 80, unit: 'Piece', emoji: '🐉', category: 'fruits' },
  { id: 'f18', name: 'Elachi Banana', price: 80, unit: 'Dozen', emoji: '🍌', category: 'fruits' },
  { id: 'f19', name: 'Banana', price: 50, unit: 'Dozen', emoji: '🍌', category: 'fruits' },
  { id: 'f20', name: 'Guava (Peru)', price: 100, unit: 'Kg', emoji: '🍐', category: 'fruits' },
  { id: 'f21', name: 'Avocado', price: 80, unit: 'Piece', emoji: '🥑', category: 'fruits' },
  { id: 'f22', name: 'Blueberry', price: 230, unit: 'Box', emoji: '🫐', category: 'fruits' },
  { id: 'f23', name: 'Lalbhag Mango', price: 180, unit: 'Kg', emoji: '🥭', category: 'fruits', seasonal: true },
  { id: 'f24', name: 'Small Alphonso Mango', price: 800, unit: 'Dozen', emoji: '🥭', category: 'fruits', seasonal: true, premium: true },
  { id: 'f25', name: 'Medium Alphonso Mango', price: 1200, unit: 'Dozen', emoji: '🥭', category: 'fruits', seasonal: true, premium: true },
  { id: 'f26', name: 'Big Alphonso Mango', price: 1400, unit: 'Dozen', emoji: '🥭', category: 'fruits', seasonal: true, premium: true },
  { id: 'f27', name: 'Papita', price: 50, unit: 'Kg', emoji: '🥭', category: 'fruits' },
  { id: 'f28', name: 'Raspberries', price: 120, unit: '250g', emoji: '🍓', category: 'fruits' },
];

const vegetables: Product[] = [
  { id: 'v1', name: 'Spinach', price: 40, unit: 'Bunch', emoji: '🥬', category: 'vegetables', outOfStock: true },
  { id: 'v2', name: 'Cabbage', price: 50, unit: 'Piece', emoji: '🥬', category: 'vegetables', outOfStock: true },
  { id: 'v3', name: 'Broccoli', price: 80, unit: 'Piece', emoji: '🥦', category: 'vegetables', outOfStock: true },
  { id: 'v4', name: 'Cauliflower', price: 60, unit: 'Piece', emoji: '🥦', category: 'vegetables', outOfStock: true },
  { id: 'v5', name: 'Lettuce', price: 70, unit: 'Piece', emoji: '🥬', category: 'vegetables', outOfStock: true },
  { id: 'v6', name: 'Kale', price: 90, unit: 'Bunch', emoji: '🥬', category: 'vegetables', outOfStock: true },
  { id: 'v7', name: 'Fenugreek (Methi)', price: 30, unit: 'Bunch', emoji: '🌿', category: 'vegetables', outOfStock: true },
  { id: 'v8', name: 'Tomato', price: 40, unit: 'Kg', emoji: '🍅', category: 'vegetables', outOfStock: true },
  { id: 'v9', name: 'Onion', price: 35, unit: 'Kg', emoji: '🧅', category: 'vegetables', outOfStock: true },
  { id: 'v10', name: 'Potato', price: 30, unit: 'Kg', emoji: '🥔', category: 'vegetables', outOfStock: true },
  { id: 'v11', name: 'Bottle Gourd (Lauki)', price: 40, unit: 'Piece', emoji: '🥒', category: 'vegetables', outOfStock: true },
  { id: 'v12', name: 'Bitter Gourd (Karela)', price: 60, unit: '500g', emoji: '🥒', category: 'vegetables', outOfStock: true },
  { id: 'v13', name: 'Ridge Gourd (Turiya)', price: 50, unit: '500g', emoji: '🥒', category: 'vegetables', outOfStock: true },
  { id: 'v14', name: 'Cucumber', price: 30, unit: '500g', emoji: '🥒', category: 'vegetables', outOfStock: true },
  { id: 'v15', name: 'Ladyfinger (Bhindi)', price: 50, unit: '500g', emoji: '🥬', category: 'vegetables', outOfStock: true },
  { id: 'v16', name: 'Eggplant (Brinjal)', price: 45, unit: '500g', emoji: '🍆', category: 'vegetables', outOfStock: true },
  { id: 'v17', name: 'Carrot', price: 50, unit: '500g', emoji: '🥕', category: 'vegetables', outOfStock: true },
  { id: 'v18', name: 'Beetroot', price: 40, unit: '500g', emoji: '🫐', category: 'vegetables', outOfStock: true },
  { id: 'v19', name: 'Radish', price: 35, unit: 'Bunch', emoji: '🥕', category: 'vegetables', outOfStock: true },
  { id: 'v20', name: 'Sweet Potato', price: 45, unit: '500g', emoji: '🍠', category: 'vegetables', outOfStock: true },
  { id: 'v21', name: 'Capsicum (Bell Pepper)', price: 60, unit: '500g', emoji: '🫑', category: 'vegetables', outOfStock: true },
  { id: 'v22', name: 'Green Beans', price: 50, unit: '500g', emoji: '🫛', category: 'vegetables', outOfStock: true },
  { id: 'v23', name: 'Green Peas', price: 70, unit: '500g', emoji: '🫛', category: 'vegetables', outOfStock: true },
  { id: 'v24', name: 'Green Chilies', price: 20, unit: '100g', emoji: '🌶️', category: 'vegetables', outOfStock: true },
  { id: 'v25', name: 'Ginger', price: 30, unit: '100g', emoji: '🫚', category: 'vegetables', outOfStock: true },
  { id: 'v26', name: 'Garlic', price: 40, unit: '100g', emoji: '🧄', category: 'vegetables', outOfStock: true },
  { id: 'v27', name: 'Coriander (Cilantro)', price: 20, unit: 'Bunch', emoji: '🌿', category: 'vegetables', outOfStock: true },
  { id: 'v28', name: 'Mint', price: 20, unit: 'Bunch', emoji: '🌿', category: 'vegetables', outOfStock: true },
  { id: 'v29', name: 'Lemon', price: 10, unit: 'Piece', emoji: '🍋', category: 'vegetables', outOfStock: true },
  { id: 'v30', name: 'Mushroom', price: 80, unit: 'Packet', emoji: '🍄', category: 'vegetables', outOfStock: true },
  { id: 'v31', name: 'Sweet Corn', price: 30, unit: 'Piece', emoji: '🌽', category: 'vegetables', outOfStock: true },
  { id: 'v32', name: 'Zucchini', price: 60, unit: 'Piece', emoji: '🥒', category: 'vegetables', outOfStock: true },
];

// Delivery charges
const deliveryRates = {
  'Thakur Complex': 20,
  'Thakur Village': 30,
  'default': 50,
};

interface CartItem {
  id: string;
  name: string;
  price: number;
  unit: string;
  emoji: string;
  quantity: number;
  category: string;
  outOfStock?: boolean;
}

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'fruits' | 'vegetables'>('all');
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [selectedDeliveryArea, setSelectedDeliveryArea] = useState('Thakur Complex');
  const [headerScrolled, setHeaderScrolled] = useState(false);
  const [cartBounce, setCartBounce] = useState(false);

  // Scroll detection for header
  useEffect(() => {
    const handleScroll = () => {
      setHeaderScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Reveal on scroll animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.reveal-on-scroll').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const addToCart = (product: typeof fruits[0]) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === product.id);
      if (existingItem) {
        return prevCart.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prevCart,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          unit: product.unit,
          emoji: product.emoji,
          quantity: 1,
          category: product.category,
          outOfStock: product.outOfStock,
        },
      ];
    });
    setCartBounce(true);
    setTimeout(() => setCartBounce(false), 300);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prevCart) =>
      prevCart
        .map((item) =>
          item.id === id ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== id));
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryCharge = deliveryRates[selectedDeliveryArea as keyof typeof deliveryRates] || deliveryRates.default;
  const finalTotal = cartTotal + (cart.length > 0 ? deliveryCharge : 0);
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const filteredProducts: Product[] = [...fruits, ...vegetables].filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || product.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const seasonalMangoes = fruits.filter((f) => f.seasonal);

  const generateWhatsAppMessage = () => {
    const shopName = 'OM SAI FRUIT';
    const itemsList = cart
      .map((item) => `• ${item.name} x ${item.quantity} (${item.unit}) - ₹${item.price * item.quantity}`)
      .join('\n');

    const message = `*🛒 ORDER - ${shopName}*

*👤 Customer Details:*
Name: ${customerName}
Address: ${customerAddress}
Delivery Area: ${selectedDeliveryArea}

*📦 Order Items:*
${itemsList}

*💰 Payment Summary:*
Subtotal: ₹${cartTotal}
Delivery Charge: ₹${deliveryCharge}
*Total Amount: ₹${finalTotal}*

*📍 Shop Address:*
Shop No. 6, Mukta Shopping Center
90 Feet Rd, Thakur Complex
Kandivali East, Mumbai 400101

*📞 Contact:* 9892779843

Thank you for ordering! 🙏`;

    return encodeURIComponent(message);
  };

  const handlePlaceOrder = () => {
    if (!customerName.trim() || !customerAddress.trim()) {
      alert('Please enter your name and address');
      return;
    }
    const whatsappUrl = `https://wa.me/919892779843?text=${generateWhatsAppMessage()}`;
    window.open(whatsappUrl, '_blank');
    setIsCheckoutModalOpen(false);
    clearCart();
    setIsCartOpen(false);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-white via-green-50 to-lime-50">
      {/* Sticky Header */}
      <header
        className={`sticky-header z-50 transition-all duration-300 ${
          headerScrolled ? 'scrolled glass-panel' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center shadow-lg pulse-glow">
                <span className="text-2xl">🥭</span>
              </div>
              <div>
                <h1 className="text-xl md:text-2xl font-bold bg-gradient-to-r from-yellow-600 via-orange-500 to-yellow-600 bg-clip-text text-transparent">
                  OM SAI FRUIT
                </h1>
                <p className="text-xs text-gray-600">Fresh & Premium</p>
              </div>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <button
                onClick={() => scrollToSection('hero')}
                className="nav-link text-gray-700 hover:text-yellow-600 font-medium"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection('seasonal')}
                className="nav-link text-gray-700 hover:text-yellow-600 font-medium"
              >
                Mango Special
              </button>
              <button
                onClick={() => scrollToSection('fruits')}
                className="nav-link text-gray-700 hover:text-yellow-600 font-medium"
              >
                Fruits
              </button>
              <button
                onClick={() => scrollToSection('vegetables')}
                className="nav-link text-gray-700 hover:text-yellow-600 font-medium"
              >
                Vegetables
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="nav-link text-gray-700 hover:text-yellow-600 font-medium"
              >
                Contact
              </button>
            </nav>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className={`relative btn-3d w-14 h-14 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg hover:shadow-xl transition-all ${
                cartBounce ? 'cart-bounce' : ''
              }`}
            >
              <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 w-7 h-7 bg-gradient-to-br from-red-500 to-red-600 text-white text-sm font-bold rounded-full flex items-center justify-center shadow-lg badge-3d">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="hero" className="relative overflow-hidden py-16 md:py-24">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 text-8xl opacity-20 floating">🥭</div>
          <div className="absolute top-40 right-20 text-6xl opacity-20 floating-slow">🍎</div>
          <div className="absolute bottom-20 left-1/4 text-7xl opacity-20 floating">🍇</div>
          <div className="absolute bottom-40 right-1/4 text-6xl opacity-20 floating-slow">🍊</div>
          <div className="absolute top-1/2 left-1/3 text-5xl opacity-15 floating">🥑</div>
          <div className="absolute top-1/3 right-1/3 text-5xl opacity-15 floating-slow">🍓</div>
        </div>

        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="text-center reveal-on-scroll">
            {/* Seasonal Badge */}
            <div className="inline-flex items-center gap-2 seasonal-badge px-6 py-3 rounded-full mb-8 shadow-lg">
              <span className="text-2xl">🥭</span>
              <span className="text-white font-bold text-lg">Seasonal Mango Special</span>
              <span className="text-2xl">🥭</span>
            </div>

            {/* Main Title */}
            <h1 className="text-5xl md:text-7xl font-bold mb-6 section-title leading-tight">
              Premium Fresh
              <br />
              <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-yellow-500 bg-clip-text text-transparent">
                Fruits & Vegetables
              </span>
            </h1>

            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Experience the finest quality produce delivered fresh to your doorstep. 
              Handpicked with care, delivered with love.
            </p>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-10">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search for fruits and vegetables..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-3d w-full px-6 py-5 pl-14 rounded-2xl text-lg border-2 border-yellow-200 focus:border-yellow-400 focus:outline-none bg-white/80 backdrop-blur"
                />
                <svg
                  className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap justify-center gap-4">
              <button
                onClick={() => scrollToSection('fruits')}
                className="btn-3d btn-gold px-8 py-4 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all"
              >
                🛒 Shop Fruits
              </button>
              <button
                onClick={() => scrollToSection('vegetables')}
                className="btn-3d btn-green px-8 py-4 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all"
              >
                🥬 View Vegetables
              </button>
              <button
                onClick={() => setIsCartOpen(true)}
                className="btn-3d btn-mango px-8 py-4 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all flex items-center gap-2"
              >
                🛍️ Go to Cart
                {cartItemCount > 0 && (
                  <span className="bg-white/30 px-3 py-1 rounded-full text-sm">
                    {cartItemCount} items
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Seasonal Mango Section */}
      <section id="seasonal" className="py-16 bg-gradient-to-b from-yellow-50 to-transparent">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12 reveal-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 section-title">
              🥭 Royal Mango Collection
            </h2>
            <p className="text-lg text-gray-600">
              The King of Fruits - Fresh, Sweet & Premium Quality
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {seasonalMangoes.map((product, index) => (
              <div
                key={product.id}
                className={`card-3d product-card p-6 mango-highlight reveal-on-scroll ${
                  product.premium ? 'ring-4 ring-yellow-400' : ''
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {product.premium && (
                  <div className="absolute top-4 right-4 bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
                    👑 Premium
                  </div>
                )}
                <div className="text-center">
                  <div className="fruit-emoji mb-4">{product.emoji}</div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">{product.name}</h3>
                  <div className="price-tag inline-block mb-4">
                    ₹{product.price} / {product.unit}
                  </div>
                  <button
                    onClick={() => addToCart(product)}
                    className="btn-3d btn-gold w-full py-3 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition-all"
                  >
                    ➕ Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fruits Section */}
      <section id="fruits" className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12 reveal-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 section-title">
              🍎 Fresh Fruits
            </h2>
            <p className="text-lg text-gray-600">
              Handpicked premium fruits for your healthy lifestyle
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex justify-center gap-4 mb-10">
            <button
              onClick={() => setActiveCategory('all')}
              className={`btn-3d px-6 py-3 rounded-xl font-semibold transition-all ${
                activeCategory === 'all'
                  ? 'btn-gold text-gray-900'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setActiveCategory('fruits')}
              className={`btn-3d px-6 py-3 rounded-xl font-semibold transition-all ${
                activeCategory === 'fruits'
                  ? 'btn-gold text-gray-900'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              🍎 Fruits
            </button>
            <button
              onClick={() => setActiveCategory('vegetables')}
              className={`btn-3d px-6 py-3 rounded-xl font-semibold transition-all ${
                activeCategory === 'vegetables'
                  ? 'btn-green text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              🥬 Vegetables
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProducts
              .filter((p) => p.category === 'fruits')
              .map((product, index) => (
                <div
                  key={product.id}
                  className="card-3d product-card p-5 reveal-on-scroll"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="text-center">
                    <div className="fruit-emoji mb-3 text-4xl">{product.emoji}</div>
                    <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2">
                      {product.name}
                    </h3>
                    {product.priceRange ? (
                      <div className="text-sm text-gray-500 mb-2">₹{product.priceRange}</div>
                    ) : null}
                    <div className="price-tag inline-block mb-4 text-sm">
                      ₹{product.price} / {product.unit}
                    </div>
                    <button
                      onClick={() => addToCart(product)}
                      className="btn-3d btn-gold w-full py-2.5 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all add-to-cart-btn"
                    >
                      ➕ Add
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Vegetables Section */}
      <section id="vegetables" className="py-16 bg-gradient-to-b from-green-50 to-transparent">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12 reveal-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 section-title">
              🥬 Fresh Vegetables
            </h2>
            <div className="out-of-stock-badge inline-block mb-4">
              ⚠️ Currently Out of Stock
            </div>
            <p className="text-lg text-gray-600">
              Coming soon! Fresh vegetables will be available shortly
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProducts
              .filter((p) => p.category === 'vegetables')
              .map((product, index) => (
                <div
                  key={product.id}
                  className="card-3d product-card p-5 out-of-stock reveal-on-scroll"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="text-center relative">
                    <div className="fruit-emoji mb-3 text-4xl opacity-50">{product.emoji}</div>
                    <h3 className="text-lg font-bold text-gray-600 mb-2 line-clamp-2">
                      {product.name}
                    </h3>
                    <div className="text-sm text-gray-400 mb-4">₹{product.price} / {product.unit}</div>
                    <div className="out-of-stock-badge text-sm py-2">
                      🔒 Out of Stock
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Delivery Info Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <div className="delivery-info rounded-3xl p-8 reveal-on-scroll">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800 mb-2">🚚 Delivery Information</h2>
              <p className="text-gray-700">Fast & Fresh Delivery to Your Doorstep</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-white/60 rounded-2xl">
                <div className="text-3xl mb-2">📍</div>
                <h3 className="font-bold text-gray-800">Thakur Complex</h3>
                <p className="text-2xl font-bold text-yellow-600">₹20</p>
              </div>
              <div className="text-center p-4 bg-white/60 rounded-2xl">
                <div className="text-3xl mb-2">🏘️</div>
                <h3 className="font-bold text-gray-800">Thakur Village</h3>
                <p className="text-2xl font-bold text-yellow-600">₹30</p>
              </div>
              <div className="text-center p-4 bg-white/60 rounded-2xl">
                <div className="text-3xl mb-2">🌍</div>
                <h3 className="font-bold text-gray-800">Other Areas</h3>
                <p className="text-2xl font-bold text-yellow-600">₹50+</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12 reveal-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 section-title">
              📍 Visit Our Store
            </h2>
            <p className="text-lg text-gray-600">
              Fresh quality you can trust, service you'll love
            </p>
          </div>

          <div className="glass-panel rounded-3xl p-8 reveal-on-scroll">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <span className="text-3xl">🏪</span> OM SAI FRUIT
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">📍</span>
                    <div>
                      <p className="font-semibold text-gray-800">Shop Address</p>
                      <p className="text-gray-600">
                        Shop No. 6, Mukta Shopping Center<br />
                        90 Feet Rd, Thakur Complex<br />
                        Kandivali East, Mumbai<br />
                        Maharashtra 400101
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">📞</span>
                    <div>
                      <p className="font-semibold text-gray-800">Contact Number</p>
                      <p className="text-gray-600">9892779843</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">👤</span>
                    <div>
                      <p className="font-semibold text-gray-800">Owner</p>
                      <p className="text-gray-600">Dilip Gupta</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-col justify-center">
                <div className="bg-gradient-to-br from-green-100 to-yellow-100 rounded-2xl p-6 text-center">
                  <p className="text-gray-700 mb-4">
                    Order fresh fruits & vegetables directly through WhatsApp!
                  </p>
                  <a
                    href="https://wa.me/919892779843"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="whatsapp-btn inline-flex items-center gap-3 px-8 py-4 rounded-2xl font-bold text-lg shadow-lg hover:shadow-xl transition-all"
                  >
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                    </svg>
                    Chat on WhatsApp
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
                  <span className="text-2xl">🥭</span>
                </div>
                <h3 className="text-xl font-bold">OM SAI FRUIT</h3>
              </div>
              <p className="text-gray-400">
                Your trusted source for premium fresh fruits and vegetables in Mumbai.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button onClick={() => scrollToSection('hero')} className="hover:text-yellow-400 transition">
                    Home
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('fruits')} className="hover:text-yellow-400 transition">
                    Fruits
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('vegetables')} className="hover:text-yellow-400 transition">
                    Vegetables
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('contact')} className="hover:text-yellow-400 transition">
                    Contact
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Contact Info</h4>
              <ul className="space-y-2 text-gray-400">
                <li>📞 9892779843</li>
                <li>👤 Dilip Gupta</li>
                <li>📍 Kandivali East, Mumbai</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>© 2026 OM SAI FRUIT. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <div
        className={`fixed inset-0 z-50 ${isCartOpen ? 'pointer-events-auto' : 'pointer-events-none'}`}
      >
        {/* Overlay */}
        <div
          className={`absolute inset-0 modal-overlay transition-opacity duration-300 ${
            isCartOpen ? 'opacity-100' : 'opacity-0'
          }`}
          onClick={() => setIsCartOpen(false)}
        />

        {/* Cart Panel */}
        <div
          className={`cart-drawer absolute right-0 top-0 h-full w-full max-w-md glass-panel shadow-2xl ${
            isCartOpen ? 'open' : ''
          }`}
        >
          <div className="flex flex-col h-full">
            {/* Cart Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                <span>🛒</span> Your Cart
              </h2>
              <button
                onClick={() => setIsCartOpen(false)}
                className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-6">
              {cart.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">🛒</div>
                  <p className="text-gray-500 text-lg">Your cart is empty</p>
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      scrollToSection('fruits');
                    }}
                    className="btn-3d btn-gold mt-4 px-6 py-3 rounded-xl font-semibold"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.id}
                      className="cart-item-animate glass-panel rounded-2xl p-4 flex items-center gap-4"
                    >
                      <div className="text-4xl">{item.emoji}</div>
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-800">{item.name}</h3>
                        <p className="text-sm text-gray-500">₹{item.price} / {item.unit}</p>
                      </div>
                      <div className="quantity-selector">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="quantity-btn"
                        >
                          −
                        </button>
                        <span className="font-bold w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="quantity-btn"
                        >
                          +
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="w-8 h-8 rounded-full bg-red-100 hover:bg-red-200 text-red-600 flex items-center justify-center transition"
                      >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Cart Summary */}
            {cart.length > 0 && (
              <div className="border-t border-gray-200 p-6 space-y-4">
                {/* Delivery Selection */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    📍 Select Delivery Area
                  </label>
                  <select
                    value={selectedDeliveryArea}
                    onChange={(e) => setSelectedDeliveryArea(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-yellow-400 focus:outline-none bg-white"
                  >
                    <option value="Thakur Complex">Thakur Complex - ₹20</option>
                    <option value="Thakur Village">Thakur Village - ₹30</option>
                    <option value="Other">Other Areas - ₹50+</option>
                  </select>
                </div>

                {/* Summary */}
                <div className="space-y-2">
                  <div className="flex justify-between text-gray-600">
                    <span>Subtotal</span>
                    <span>₹{cartTotal}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Delivery Charge</span>
                    <span>₹{deliveryCharge}</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-gray-800 pt-2 border-t border-gray-200">
                    <span>Total</span>
                    <span className="text-yellow-600">₹{finalTotal}</span>
                  </div>
                </div>

                {/* Checkout Button */}
                <button
                  onClick={() => setIsCheckoutModalOpen(true)}
                  className="whatsapp-btn w-full py-4 rounded-2xl font-bold text-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                  Place Order on WhatsApp
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      {isCheckoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="modal-overlay absolute inset-0" onClick={() => setIsCheckoutModalOpen(false)} />
          <div className="glass-panel rounded-3xl p-8 max-w-md w-full relative z-10 animate-[scale-in_0.3s_ease-out]">
            <button
              onClick={() => setIsCheckoutModalOpen(false)}
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
              <span>📝</span> Order Details
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Your Name *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-yellow-400 focus:outline-none bg-white"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Delivery Address *
                </label>
                <textarea
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  placeholder="Enter your complete address"
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-yellow-400 focus:outline-none bg-white resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Delivery Area
                </label>
                <select
                  value={selectedDeliveryArea}
                  onChange={(e) => setSelectedDeliveryArea(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-yellow-400 focus:outline-none bg-white"
                >
                  <option value="Thakur Complex">Thakur Complex - ₹20</option>
                  <option value="Thakur Village">Thakur Village - ₹30</option>
                  <option value="Other">Other Areas - ₹50+</option>
                </select>
              </div>

              {/* Order Summary */}
              <div className="bg-yellow-50 rounded-2xl p-4 space-y-2">
                <h3 className="font-bold text-gray-800 mb-2">📦 Order Summary</h3>
                {cart.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.name} x {item.quantity}</span>
                    <span className="font-semibold">₹{item.price * item.quantity}</span>
                  </div>
                ))}
                <div className="border-t border-yellow-200 pt-2 mt-2 space-y-1">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Subtotal</span>
                    <span>₹{cartTotal}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Delivery</span>
                    <span>₹{deliveryCharge}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg text-yellow-600">
                    <span>Total</span>
                    <span>₹{finalTotal}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handlePlaceOrder}
                className="whatsapp-btn w-full py-4 rounded-2xl font-bold text-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                </svg>
                Send Order via WhatsApp
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
